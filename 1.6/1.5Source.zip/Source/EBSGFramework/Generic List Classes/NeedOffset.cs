﻿using RimWorld;

namespace EBSGFramework
{
    public class NeedOffset
    {
        public NeedDef need;
        public float offset;
        public float factor;
        public StatDef offsetFactorStat;
    }
}
