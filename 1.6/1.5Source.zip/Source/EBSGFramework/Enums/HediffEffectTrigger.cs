﻿namespace EBSGFramework
{
    public enum RemovedHediffEffectTrigger
    {
        Always,
        OnDeathOnly,
        OnRemovalOnly
    }
}
