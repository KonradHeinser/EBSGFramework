﻿namespace EBSGFramework
{
    public class HediffCompProperties_ExplodingMeleeAttacks : BurstHediffPropertiesBase
    {
        public HediffCompProperties_ExplodingMeleeAttacks()
        {
            compClass = typeof(HediffComp_ExplodingMeleeAttacks);
        }
    }
}
