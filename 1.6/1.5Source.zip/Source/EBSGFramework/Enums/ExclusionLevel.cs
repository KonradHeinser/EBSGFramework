﻿namespace EBSGFramework
{
    public enum ExclusionLevel
    {
        None,
        Self,
        Allies,
        NonHostiles
    }
}
