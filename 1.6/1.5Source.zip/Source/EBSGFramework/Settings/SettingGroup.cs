﻿using Verse;

namespace EBSGFramework
{
    public class SettingGroup
    {
        [MustTranslate]
        public string label;
    }
}
