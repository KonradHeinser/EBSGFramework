﻿using Verse;

namespace EBSGFramework
{
    public class ConditionDuration
    {
        public GameConditionDef condition;
        public int ticks = 60000;
    }
}
