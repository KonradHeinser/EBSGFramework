﻿using System;
namespace EBSGFramework
{
    public class HediffCompProperties_ExplosiveRetaliation : BurstHediffPropertiesBase
    {
        public HediffCompProperties_ExplosiveRetaliation()
        {
            compClass = typeof(HediffComp_ExplosiveRetaliation);
        }
    }
}
