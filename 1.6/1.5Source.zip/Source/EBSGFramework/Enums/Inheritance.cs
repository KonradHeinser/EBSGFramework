﻿namespace EBSGFramework
{
    public enum Inheritance
    {
        Same,
        Xeno,
        Endo
    }
}
