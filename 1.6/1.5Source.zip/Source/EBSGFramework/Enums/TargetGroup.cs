﻿namespace EBSGFramework
{
    public enum TargetGroup
    {
        None,
        Player,
        NonPlayer,
        Hostiles,
        NoFaction
    }
}
