﻿using RimWorld;

namespace EBSGFramework
{
    public class NeedOffset
    {
        public NeedDef need;
        public float offset;
        public StatDef offsetFactorStat;
    }
}
