﻿using RimWorld;
namespace EBSGFramework
{
    public class StatCheck
    {
        public StatDef stat;
        public float minStatValue = 0f;
        public float maxStatValue = 99999f;
    }
}
