﻿using Verse;

namespace EBSGFramework
{
    public class HediffComp_PreventSlaveRebellion : HediffComp
    {
        private HediffCompProperties_PreventSlaveRebellion Props => (HediffCompProperties_PreventSlaveRebellion)props;
    }
}
