﻿using Verse;

namespace EBSGFramework
{
    public class CompEBSGPlaceworker : ThingComp
    {
        public CompProperties_GathererSpot Props => (CompProperties_GathererSpot)props;
    }
}
