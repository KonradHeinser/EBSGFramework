﻿using Verse;
namespace EBSGFramework
{
    public class CapCheck
    {
        public PawnCapacityDef capacity;
        public float minCapValue = 0f;
        public float maxCapValue = 9999f;
    }
}
