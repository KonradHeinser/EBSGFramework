﻿using Verse;

namespace EBSGFramework
{
    public class HediffSeverityLevel
    {
        public HediffDef hediff;

        public float minSeverity = 0f;

        public float maxSeverity = 99999f;
    }
}
