﻿using Verse;

namespace EBSGFramework
{
    public class HediffCompProperties_PreventDeathNotifications : HediffCompProperties
    {
        public HediffCompProperties_PreventDeathNotifications()
        {
            compClass = typeof(HediffComp_PreventDeathNotifications);
        }
    }
}
