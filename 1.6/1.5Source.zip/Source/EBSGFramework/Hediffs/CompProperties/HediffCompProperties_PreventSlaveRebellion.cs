﻿using Verse;

namespace EBSGFramework
{
    public class HediffCompProperties_PreventSlaveRebellion : HediffCompProperties
    {
        public HediffCompProperties_PreventSlaveRebellion()
        {
            compClass = typeof(HediffComp_PreventSlaveRebellion);
        }
    }
}
