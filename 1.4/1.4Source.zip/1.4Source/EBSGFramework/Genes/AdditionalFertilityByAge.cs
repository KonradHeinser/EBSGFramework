﻿using Verse;

namespace EBSGFramework
{
    public class AdditionalFertilityByAge : HediffAdder
    {
        // This class was only made to make it require less work to find out if it's worth going everything in depth.
    }
}
