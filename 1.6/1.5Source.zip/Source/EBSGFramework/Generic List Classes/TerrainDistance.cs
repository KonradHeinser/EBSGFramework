﻿using Verse;

namespace EBSGFramework
{
    public class TerrainDistance
    {
        public TerrainDef terrain;

        public float maxDistance = 10; // Item must be in this area 

        public int count = 1;
    }
}
