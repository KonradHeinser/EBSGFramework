﻿using RimWorld;

namespace EBSGFramework
{
    public class SkillXP
    {
        public SkillDef skill;
        public int experience;
    }
}
