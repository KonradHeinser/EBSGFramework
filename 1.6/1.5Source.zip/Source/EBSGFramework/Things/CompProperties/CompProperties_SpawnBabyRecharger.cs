﻿using Verse;

namespace EBSGFramework
{
    public class CompProperties_SpawnBabyRecharger : CompProperties
    {
        public CompProperties_SpawnBabyRecharger()
        {
            compClass = typeof(CompSpawnBabyRecharger);
        }
    }
}
