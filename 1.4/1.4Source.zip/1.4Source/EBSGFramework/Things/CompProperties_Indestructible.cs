﻿using Verse;
namespace EBSGFramework
{
    public class CompProperties_Indestructible : CompProperties
    {
        public CompProperties_Indestructible()
        {
            compClass = typeof(CompIndestructible);
        }
    }
}
