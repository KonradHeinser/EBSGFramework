﻿using System;
namespace EBSGFramework
{
    public class HediffCompProperties_ExplodingRangedAttacks : BurstHediffPropertiesBase
    {
        public HediffCompProperties_ExplodingRangedAttacks()
        {
            compClass = typeof(HediffComp_ExplodingRangedAttacks);
        }
    }
}
