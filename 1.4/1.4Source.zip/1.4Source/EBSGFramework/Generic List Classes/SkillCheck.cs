﻿using RimWorld;

namespace EBSGFramework
{
    public class SkillCheck
    {
        public SkillDef skill;
        public int minLevel = 0;
        public int maxLevel = 20;
    }
}
