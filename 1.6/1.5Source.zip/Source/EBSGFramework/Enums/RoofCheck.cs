﻿namespace EBSGFramework
{
    public enum RoofCheck
    {
        NoCheck,
        NoRoof,
        NoThickRoof,
        AnyRoof,
        ThickRoof
    }
}
