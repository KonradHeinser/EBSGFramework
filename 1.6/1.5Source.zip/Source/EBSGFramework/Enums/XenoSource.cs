﻿namespace EBSGFramework
{
    public enum XenoSource
    {
        Father,
        Mother,
        Hybrid
    }
}
