﻿namespace EBSGFramework
{
    public enum Gases
    {
        Smoke = 0,
        None = 1,
        Tox = 8,
        Rot = 16
    }
}
