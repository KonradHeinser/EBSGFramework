﻿using Verse;

namespace EBSGFramework
{
    internal class TurretRoofBlocked : DefModExtension
    {
    }
}
