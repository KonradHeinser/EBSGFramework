﻿namespace EBSGFramework
{
    public class HediffCompProperties_ExplodeOnDeath : BurstHediffPropertiesBase
    {
        public HediffCompProperties_ExplodeOnDeath()
        {
            compClass = typeof(HediffComp_ExplodeOnDeath);
        }
    }
}
