﻿using System.Collections.Generic;
using Verse;

namespace EBSGFramework
{
    public class SettingCategoryDef : Def
    {
        public List<SettingGroup> settingGroups = new List<SettingGroup>();
    }
}
