﻿namespace EBSGFramework
{
    public class ModuleSlot
    {
        public string slotID;
        public string slotName = "Undefined";
        // -1 means unlimited capacity
        public float capacity = -1f;
    }
}
