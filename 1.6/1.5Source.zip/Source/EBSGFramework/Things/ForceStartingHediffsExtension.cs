﻿using Verse;

namespace EBSGFramework
{
    public class ForceStartingHediffsExtension : DefModExtension
    {
    }
}
