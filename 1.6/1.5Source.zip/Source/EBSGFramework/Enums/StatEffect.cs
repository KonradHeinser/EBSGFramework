﻿namespace EBSGFramework
{
    public enum StatEffect
    {
        Multiply,
        Divide,
        OneMinusMultiply,
        OneMinusDivide
    }
}
