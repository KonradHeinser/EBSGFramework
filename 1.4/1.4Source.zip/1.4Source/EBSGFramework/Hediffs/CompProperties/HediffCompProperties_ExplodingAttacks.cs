﻿namespace EBSGFramework
{
    public class HediffCompProperties_ExplodingAttacks : BurstHediffPropertiesBase
    {
        public HediffCompProperties_ExplodingAttacks()
        {
            compClass = typeof(HediffComp_ExplodingAttacks);
        }
    }
}
