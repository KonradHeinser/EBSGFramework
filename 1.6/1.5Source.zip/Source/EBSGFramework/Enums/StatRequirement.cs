﻿namespace EBSGFramework
{
    public enum StatRequirement
    {
        Always,
        Higher,
        Lower,
        Pawn,
        PawnHigher,
        PawnLower,
        NonPawn,
        NonPawnHigher,
        NonPawnLower,
        Humanlike,
        HumanlikeHigher,
        HumanlikeLower
    }
}
