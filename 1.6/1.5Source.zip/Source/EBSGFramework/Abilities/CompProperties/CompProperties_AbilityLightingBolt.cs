﻿using RimWorld;

namespace EBSGFramework
{
    public class CompProperties_AbilityLightingBolt : CompProperties_AbilityEffect
    {
        public CompProperties_AbilityLightingBolt()
        {
            compClass = typeof(CompAbilityEffect_LightningBolt);
        }
    }
}
