﻿using Verse;
namespace EBSGFramework
{
    public class CarefulOperation
    {
        public PatchOperation operation;

        public string failPoint = "";
    }
}
